# Watermark Off — For Teachers

<div align="center">

**Remove Google Gemini AI sparkle watermarks from images instantly.**

100% client-side. Your images never leave your device.

![License](https://img.shields.io/badge/license-MIT-blue)
![React](https://img.shields.io/badge/React-19-61DAFB)
![Vite](https://img.shields.io/badge/Vite-7-646CFF)

</div>

---

## About

**Watermark Off** is a professional web tool designed specifically for teachers to remove the Google Gemini AI sparkle watermark from generated images. It uses **reverse alpha blending** with a precisely extracted watermark alpha map to achieve pixel-perfect restoration.

### How It Works

Google Gemini composites a semi-transparent white sparkle star onto generated images at a fixed position. This tool reverses that operation mathematically:

```
original = (blended - 255 * alpha) / (1 - alpha)
```

The exact alpha map of the Gemini sparkle was extracted by comparing watermarked and clean versions of real Gemini images. This allows the tool to restore the original pixels underneath the watermark with near-zero error.

### Features

- **Automatic removal** — Upload an image and the watermark is removed instantly
- **Pixel-perfect** — Reverse alpha blending restores original pixels (mean error < 1/255)
- **100% private** — All processing happens in your browser. No uploads, no servers
- **Bilingual** — Full Arabic/English language toggle with RTL support
- **Before/After view** — Side-by-side comparison of original and cleaned images
- **Multiple formats** — Download as PNG or JPEG with adjustable quality

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) 18 or later
- [pnpm](https://pnpm.io/) (recommended) or npm

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/watermark-off.git
cd watermark-off

# Install dependencies
pnpm install
# or: npm install

# Start the dev server
pnpm dev
# or: npm run dev
```

The app will be available at `http://localhost:5173`.

### Build for Production

```bash
pnpm build
# or: npm run build
```

The built files will be in the `dist/` folder. You can deploy them to any static hosting service (Netlify, Vercel, GitHub Pages, etc.).

## Tech Stack

- **React 19** + **TypeScript**
- **Vite 7** (build tool)
- **Tailwind CSS 4**
- **Canvas API** (browser-native image processing)

## Gemini Watermark Details

| Image Size | Watermark Size | Padding from Edge |
|---|---|---|
| max(W,H) > 1024 | 96 x 96 px | 64 px |
| max(W,H) <= 1024 | 48 x 48 px | 32 px |

The watermark is a 4-pointed sparkle star with ~51% maximum opacity, composited as a white overlay.

## Author

**Emad A. Mohamed**

Designed with all :heart:

## License

This project is licensed under the MIT License.
